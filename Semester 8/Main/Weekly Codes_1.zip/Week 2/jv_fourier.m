function r = jv_fourier(jv,sx,qx,qy)
[m,n] = size(sx);

syms jvq c;

jvq = 0;

for i2 = 1:m
    for j2 = 1:n
        for i1 = 1:m
            for j1 = 1:n
                c = which_j(i1,i2,j1,j2);
                jvq = jvq + jv(c)*exp(-2i*pi*(qx*(i1-i2) + qy*(j1-j2))); 
            end
        end
    end
end
jvq = jvq/2;

r = jvq;
end