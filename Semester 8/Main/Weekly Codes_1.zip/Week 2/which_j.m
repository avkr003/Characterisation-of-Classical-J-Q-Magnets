function r = which_j(i1,i2,j1,j2)
y = abs(i1-i2)+abs(j1-j2);

if y <= 2 && y >0
    r = y;
else
    r = 4;
end

end
