function [qx,qy] = qvxy(t,m,n)

r = ones(m*n,2);
syms k;
k = 1;
for i = -m/2+1 : 1 : m/2
    x(k) = i/m;
    k=k+1;
end
k = 1;
for i = -n/2+1 : 1 : n/2
    y(k) = i/n;
    k=k+1;
end

p = 1;

for i = 1:m:m*n
    k = 1;
    for j = i:1:i+m-1
        r(j,1) = x(p);
        r(j,2) = y(k);
        k = k + 1;
    end
    p = p + 1;
end
%disp(r);
qx = r(t,1);
qy = r(t,2);

end