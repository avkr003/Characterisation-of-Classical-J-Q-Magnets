function r = system_energy(jv,qv,m,n,x,y,z)

r = 0;

parfor i = 1:m
    for j = 1:n
        r = r + spin_energy(i,j,jv,qv,x,y,z);
    end
end

r = r/2;
end