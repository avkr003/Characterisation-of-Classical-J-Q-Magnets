k=8;
c = ones(k,k);

for t=1:k
    for j=1:k
        c(t,j) = ((-1)^(t+j))*c(t,j);
    end
end