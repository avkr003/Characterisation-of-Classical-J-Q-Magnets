syms sx sy sz;
syms m n;

jv(1) = 1;
jv(2) = 0.5;
qv = 0.0;

m = 4;
n = 4;

d = '2d';

iterations = 5000;
%statistics = 1;
limit = 100;
%typ(4) = 0;

tic;
%for mit = 1:statistics
[sx,sy,sz] = spin(jv,qv, iterations,limit,m,n,d);%,mit);

sq = plot_sq2(sx,sy,sz);%,mit);                                                    %   BTP 1
%plot_sqp(sx,sy,sz);
%typ = stat(typ,statistics,sq,mit);

%plot_qv_fourier(qv,m,n);
        
%hq = t_hamiltonain_f(sx,sy,sz,jv,qv);        

%end
%figure;
%q = 1:1:4;
%scatter(q,typ,150,'.');


toc;
        
               
        