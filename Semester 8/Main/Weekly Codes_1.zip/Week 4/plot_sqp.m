function plot_sqp(sx,sy,sz)

[m,n] = size(sx);



[qx,qy] = qxqy(m,n);

fsq = figure;
hold;

for i = 1:m
    t1 = qx(i);
    for j = 1:n
        [sqx,sqy,sqz] = sqc(sx,sy,sz, t1,qy(j));

        plot3(t1,qy(j),angle(sqz), '*');
        title('|Sq2 vs qx & qy');
        xlabel('qx'); 
        ylabel('qy'); 
        zlabel('|Sq2|');
        grid on;

    end
end
%disp(sum_sq2);

%folder = '/home/abhinav/Desktop/Week 4/Results/many_runs/Sq_square';
%pngFileName = sprintf('Sq_%d.fig', mit);
%fullFileName = fullfile(folder, pngFileName);
%saveas(fsq,fullFileName);
%close(fsq);

end
