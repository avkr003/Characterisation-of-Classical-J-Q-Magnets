function [x,y,z,m,n] = spin(jv, iterations,m,n)
syms x y z x0 y0 z0;

rand;  

d = 1;                                                                     %Change 1 to any other value for 3d              

if d == 1
    theta = (pi/2)*ones(m,n);
else
    theta =(pi/2)*rand(m,n);
end
phi = 2 * pi * rand(m,n);

x = sin(theta).*cos(phi);
y = sin(theta).*sin(phi);
z = cos(theta);

zp = ones(m,n);
%figure;
quiver3(zp,flipud(x),flipud(y),flipud(z));  
hold on;
p(1,1) = system_energy(jv,x,y,z);

for k = 1: iterations
    i = irandom(m);
    j = irandom(n);
    x0 = x;
    y0 = y;
    z0 = z;
    [x(i,j), y(i,j), z(i,j)] = component(i, j, jv, x, y, z);   %c
    
    p(k+1,1) = system_energy(jv,x,y,z);
    
    quiver3(zp,flipud(x),flipud(y),flipud(z)); 
    if p(k+1)- p(k) > 100
        %arrayplot(x0,y0,z0);
        %arrayplot(x,y,z);
        disp(i);
        disp(j);
        disp(spin_energy(i,j,jv,x0,y0,z0));
        disp(spin_energy(i,j,jv,x,y,z));
        disp('true')
        %break;
    end
    
    if k > 201 && p(k-200,1) - p(k,1) <= 0.1
        disp(k); 
        break;       
    end
    
end
hold off;      
q = 1:1:k + 1;
figure;
scatter(q,p,130,'.');
%sarrayplot(x,y,z);
end

                