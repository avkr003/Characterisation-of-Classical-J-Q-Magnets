syms oren;
syms j1;
syms j2
syms o;
j1 = 1;
j2 = 0;
oren = 2* pi * rand(4,4);
syms tener minenergy c b
c = ones(4);
b = ones(4);
tener = 0;

for i = 1:4
    for j = 1:4
        c(i,j) = energy(i , j ,j1, j2, oren);
        b(i,j) = c(i,j);
        tener = tener + c(i,j);
    end
end
minenergy = tener;
for k = 1: 1000
    for i = 1:4
        for j = 1:4
            o = oren(i,j);
            oren(i,j) = 2*pi*rand;
            c(i,j) = energy(i , j , j1, j2, oren);
            if minenergy > (tener - b(i,j) + c(i,j))
                tener = tener - b(i,j) + c(i,j);
                minenergy = tener;
                b(i,j) = c(i,j);
            else
                oren(i,j) = o;
            end
        end
    end
end

                