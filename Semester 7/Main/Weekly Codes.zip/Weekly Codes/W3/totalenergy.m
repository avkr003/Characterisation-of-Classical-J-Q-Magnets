function y = totalenergy(j1,j2,oren)
    syms m n;
    [m,n] = size(oren);
    c = ones(m,n);
    for i = 1 : m
        for j = 1 : n
            c(i,j) = energy(i,j,j1,j2,oren)/2;
        end
    end
    y = sum(sum(c),2);
end
