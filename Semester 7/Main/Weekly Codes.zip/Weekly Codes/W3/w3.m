syms oren;
syms j1;
syms j2
syms o;
syms tener minenergy c b;

j1 = 1;
j2 = 0.25;
tener = 0;
iterations = 25000;

c = ones(4);
b = ones(4);
p = ones(iterations,1);

oren = 2*pi * rand(4,4);

for i = 1:4                         %calculating total energy of system. Double counting is occuring
    for j = 1:4
        c(i,j) = energy(i , j ,j1, j2, oren);
        b(i,j) = c(i,j);
        tener = tener + c(i,j);
    end
end

tener = tener/2;                    %dividing by 2 to counter double counting
minenergy = tener;

for k = 1: iterations
    i = irandom();
    j = irandom();
    o = oren(i,j);
    oren(i,j) = 2*pi*rand;
    c(i,j) = energy(i , j , j1, j2, oren);        
    if minenergy >= (tener - b(i,j) + c(i,j))
        tener = tener - b(i,j) + c(i,j);
        minenergy = tener;
        b(i,j) = c(i,j);
    else
        oren(i,j) = o;
    end
    p(k,1) = minenergy;
end
x = 1:1:iterations;
scatter(x,p,16);
                