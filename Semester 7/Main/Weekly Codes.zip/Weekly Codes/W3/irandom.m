function y = irandom()
    syms z;
    z =  rand;
    if z <= 0.25
        y = 1;
    elseif z <= 0.5 && z > 0.25
        y = 2;
    elseif z <= 0.75 && z > 0.5
        y = 3;
    elseif z >= 0.75
        y = 4;
    end
end
        