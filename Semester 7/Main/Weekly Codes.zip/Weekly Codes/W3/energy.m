function y = energy(a,b, j1, j2, oren)
    syms m n;
    [m,n] = size(oren);
    syms r1 r2 c1 c2;
    if a == 1 
        r1  = m;
    else
        r1 = a - 1;
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%   
    if b == 1 
        c1  = n;
    else
        c1 = b - 1;
    end
 %%%%%%%%%%%%%%%%%   
    if b == n 
        c2  = 1;
    else
        c2 = b + 1;
    end
 %%%%%%%%%%%%   
    if a == m 
        r2  = 1;
    else
        r2 = a + 1;
    end
    %%%%%%%%%%%%%
    y1 = j1*cos(oren(a,b) - oren(r1,b));
    y2 = j1*cos(oren(a,b) - oren(a,c1));
    y3 = j1*cos(oren(a,b) - oren(r2,b));
    y4 = j1*cos(oren(a,b) - oren(a,c2));
    
    y5 = j2*cos(oren(a,b) - oren(r1,c1));
    y6 = j2*cos(oren(a,b) - oren(r1,c2));
    y7 = j2*cos(oren(a,b) - oren(r2,c1));
    y8 = j2*cos(oren(a,b) - oren(r2,c2));
    
    y = y1 + y2 + y3 + y4 + y5 + y6 + y7 + y8;
end
