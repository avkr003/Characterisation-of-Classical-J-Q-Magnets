syms theta phi;
syms ox oy oz;
syms ox1 oy1 oz1;
syms ox2 oy2 oz2;
syms tener minenergy c b;
syms x y z;

m = 4;
n = 4;                                    

jv(1) = 1;
jv(2) = 1;

tener = 0;
iterations = 350;

rand;                                           %first random number of matlab is not random so to call it for start

%c = zeros(m,n);                                  %variable to store new change
b = zeros(m,n);                                  % variable to store previous value before reorientation

p = ones(iterations,1);                         % plotting points

theta = pi* rand(m,n);                          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%33
phi = 2 * pi * rand(m,n);

x = sin(theta).*cos(phi);
y = sin(theta).*sin(phi);
z = cos(theta);

ox = x;
oy = y;
oz = z;

for i = 1:m                                     %calculating total energy of system. Double counting is occuring
    for j = 1:n
        c = energy3dangle(i , j , jv, theta, phi);
        b(i,j) = c;
        tener = tener + c;
    end
end

tener = tener/2;                                %dividing by 2 to counter double counting
minenergy = tener;

for k = 1: iterations
    i = irandom(m);
    j = irandom(n);
    ox1 = x;
    oy1 = y;
    oz1 = z;
    [x(i,j), y(i,j), z(i,j), c] = energycomp(i, j, jv, x, y, z);
    tener = tener - b(i,j) + c;
    b(i,j)  = c;
%     if b(i,j) < c
%         ox2 = x;
%         oy2 = y;
%         oz2 = z;
%         break;
%     else
%         b(i,j)  = c;
%     end
%     if (tener - b(i,j) + c) <= tener
%         tener = tener - b(i,j) + c;
%         b(i,j)  = c;        
%         ox(i,j) = x(i,j);
%         oy(i,j) = y(i,j);
%         oz(i,j) = z(i,j);
%     else
%         x(i,j) = ox(i,j);
%         y(i,j) = oy(i,j);
%         z(i,j) = oz(i,j);
%         c = b(i,j);
%     end
    
    minenergy = tener;
    p(k,1) = minenergy;
end

q = 1:1:iterations;
figure;
scatter(q,p,130,'.');

arrayplot(x,y,z);
% if p(iterations,1) == 1
%     arrayplot(ox1,oy1,oz1);
%     arrayplot(ox2,oy2,oz2);
% else
%     arrayplot(x,y,z);
% end
                