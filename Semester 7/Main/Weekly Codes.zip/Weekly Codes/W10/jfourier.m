function rt = jfourier(m,n,jv,qx,qy)        % x is used here only to determine size of matrix, that is m & n                                                         
    syms jf c;
        
    jf = 0;                         % Main variable                                                               
    c = 0;                          % The term we will add to jf after evaluation one of the terms of
                                    % the summation for a given 'i' correspoding to given 'j'    
    for i=1:1:m*n                   % 'i' varies from 1 to m*n & corresponds to 'r_i' in R_(ij) = r_j - r_i 
        for j=1:1:n*m               % 'j' varies from 1 to n*m & corresponds to 'r_j' in R_(ij) = r_j - r_i
            %%%%%%%%%%%%%%%
            yi = ceil(i/n);         % If 'i' and 'j' is numbered from left to right as 1,2,3,4,5...(next row),6,7,8...
            yj = ceil(j/n);         % then 'y' coordinate of i lattice point will be ceil(i/n). Same goes for j point.
            %%%%%%%%%%%%%%%         
            xi = mod(i,n);          % For x coordinate of i lattice point, it will be mod(i,n) and it will be 'n' if 
            if xi == 0              % value of mod(i,n) comes to be 0.
                xi = n;
            end
            %%%%%%%%%%%%%%%
            xj = mod(j,n);          % If lattice was numbered from top to bottom instead of left to right,  
            if xj == 0              % that is 1,m+1,2m+1,3m+1...(next row),2,m+2,2m+2...(next row),3,m+3,2m+3... 
                xj = n;             % then yi = ceil(i/m) and xi = mod(i,m) and xi = m if xi =0 for given 'i'
            end
            %%%%%%%%%%%%%%%
            dx = xj - xi;           % Now q.R_(ij) = qx*dx + qy*dy
            dy = yj - yi;
            %%%%%%%%%%%%%%%
            if dx == n - 1
                dx = -1;
            end
            if dx == 1 - n
                dx = 1;             % These 4 'if' are for correcting the boundary/periodic conditions
            end                     % and are valid how 'i' & 'j' are numbered, that is,
            if dy == m - 1          % either 'top to bottom' or 'left to right'.
                dy = -1;
            end
            if dy == 1 - m
                dy = 1;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if dx - dy == 1 || dx - dy == -1                    % Value of c for "nearest" neighbouring spins
                c = jv(1)*exp(-1i*2*pi*(qx*dx + qy*dy));        % but this also include cases for which 'c' should be 0 
            end
            if dx - dy == 2 || dx - dy == -2 || dx - dy == 0    % Value of c for "next nearest" neighbouring spins
                c = jv(2)*exp(-1i*2*pi*(qx*dx + qy*dy));        % but this also include cases for which 'c' should be 0 
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if i == j
                c = 0;                                          % To exclude cases for which c = 0, these 2 'if' cases has to
            end                                                 % be below the above 2 'if'.
            if dx > 1 || dx < -1 || dy > 1 || dy < -1           % for i = j, J = 0, that is J for self interaction is 0
                c = 0;                                          % for spins outside 8 nearest lattice points, J = 0
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            jf = jf + c;                                        % Final summation
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
    end
    rt = jf;
end    