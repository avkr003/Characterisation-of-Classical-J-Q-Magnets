function y = irandom(t)
    z =  rand;
    y =  ceil(z*t);
end
        