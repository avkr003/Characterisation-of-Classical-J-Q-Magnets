function y = calenergy(j,theta1, phi1, theta2, phi2)
    y = j*(sin(phi1)*sin(phi2)* cos(theta1 - theta2) + cos(phi1)*cos(phi2));
end