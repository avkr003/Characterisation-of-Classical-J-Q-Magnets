syms jf jm;
syms qx qy;
syms qxm qym;
syms datax datay dataz;

m = 4;
n = 4;

jv(1) = 1;
jv(2) = 1.1;

jm = 0;

%qxm = 1;
%qym = 1;

figure;
hold;

for qx = -m/2+1 : 1 : m/2
    for qy = -n/2+1 : 1 : n/2
        datax = qx/m;
        datay = qy/n;
        if n == 1
            datay = 0;
        end
        js = jfourier(m,n,jv,datax,datay);
        dataz = power(js*conj(js),0.5);
        plot3(datax, datay, dataz,'*');
        grid on;
        if jm > js*conj(js)                              % change to > to have minimum value of J(q)
            jm = js*conj(js);
            qxm = qx;
            qym = qy;
        end
    end
end