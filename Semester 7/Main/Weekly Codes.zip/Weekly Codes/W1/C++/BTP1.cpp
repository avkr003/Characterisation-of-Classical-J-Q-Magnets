#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <time.h>

using namespace std;

double energy(int a,int b ,int j1,int j2,double oren[][4]) {
    int r1, r2, c1, c2, dr1, dr2, dc1, dc2, m , n;
    m = 3;
    n = 3;
    double out;
/////////////////////////////////
    if (a == 0 )
    {
        r1  = m;
        dr1 = m;
    }
    else
    {
        r1 = a - 1;
        dr1 = a - 1;
    }
/////////////////////////////////
    if (b == 0 )
    {
        c1  = n;
        dc1 = n;
    }
    else
    {
        c1 = b - 1;
        dc1 = b - 1;
    }
////////////////////////////
    if (b == n )
    {
        c2  = 0;
        dc2 = 0;
    }
    else
        {
            c2 = b + 1;
            dc2 = b+1;
        }
/////////////////////////////////
    if (a == m )
    {
        r2  = 0;
        dr2 = 0;
    }
    else
    {
        r2 = a + 1;
        dr2 = a +1;
    }
//////////////////////////////////////
    out = j1*((cos(oren[a][b] - oren[r1][b])) + cos(oren[a][b] - oren[a][c2]) + cos(oren[a][b] - oren[r2][b])+ cos(oren[a][b] - oren[a][c2]))+j2 * ((cos(oren[a][b] - oren[dr1][dc1]) +cos(oren[a][b] - oren[dr1][dc2]) + cos(oren[a][b] - oren[dr2][dc1])+ cos(oren[a][b] - oren[dr2][c2])));


    return out;
}

int main()
{
        int j1, j2;
        j1 = 2;
        j2 = 1;

        double ory[4][4];
        double c[4][4];
        double b[4][4];
        double minenergy, tener, o;
        double pi = 3.141592653589793238463;
        tener = 0;
        for(int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                ory[i][j] = 2*pi * (rand() % 10000)/10000;
                //cout<<ory[i][j]<<"\n";
            }
        }
        for(int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                c[i][j] = energy(i, j, j1, j2, ory);
                b[i][j] = c[i][j];
                tener = tener + c[i][j];
                cout<<c[i][j]<<"\n";
            }
        }

        //cout<<tener<<"\n";
        minenergy = tener;

        for(int k = 0; k < 1000; k++)
        {
            for(int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    o = ory[i][j];
                    //srand(time(0));
                    ory[i][j] =2* pi * (rand() % 1000)/1000;
                    //cout<<ory[i][j]<<"\n";
                    //cout<<minenergy<<"\n";
                    c[i][j] = energy(i, j, j1, j2, ory);
                    //cout<<c[i][j]<<"\n";
                    if (minenergy > (tener - b[i][j] + c[i][j]))
                    {
                        cout<<"achieved ";
                        tener = tener - b[i][j] + c[i][j];
                        minenergy = tener;
                        b[i][j] = c[i][j];
                        cout<<minenergy<<"\n";
                    }
                    else
                    {
                        ory[i][j] = o;
                    }
                }
            }
        }//while (ory[2][2] !=  ory[4][4] );
        for(int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                cout<<ory[i][j]<<"\n";
                //cout<<oren[i][j]<<"\n";
            }
        }
        //cout<<minenergy<<"\n";
        //cout<<energy(3,4, 10,5, oren);
        return 0;
}
