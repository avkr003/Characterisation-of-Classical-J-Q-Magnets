#include <iostream>
#include<cmath>

using namespace std;
double energy()
 main()
{
    double t[3][3];
    const double pi  = 3.141592653589793238463;
    double energy = 1000;
    double minenergy = energy;
    for(int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                t[i][j] = 2*pi * (rand() % 10000)/10000;
                //cout<<oren[i][j]<<"\n";
            }
        }
    return 0; // 480*2+ 560+5908, 7.7,14.9

}
