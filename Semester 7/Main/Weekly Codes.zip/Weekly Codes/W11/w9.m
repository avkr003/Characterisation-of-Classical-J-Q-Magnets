%function rt = w9(jv)
syms ox1 oy1 oz1 c0 c1 b1;
%syms tener minenergy c b;
syms x y z;

m = 4;
n = 4;                                    

jv(1) = 1;
jv(2) = 1.2;

%tener = 0;
iterations = 700;

rand;                                           %first random number of matlab is not random so to call it for start

%c = zeros(m,n);                                  %variable to store new change
%b = zeros(m,n);                                  % variable to store previous value before reorientation

%p = ones(iterations,1);                         % plotting points

theta = pi* rand(m,n);                          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%33
phi = 2 * pi * rand(m,n);

x = sin(theta).*cos(phi);
y = sin(theta).*sin(phi);
z = cos(theta);

%for i = 1:m                                     %calculating total energy of system. Double counting is occuring
 %   for j = 1:n
  %      c = energy3dangle(i , j , jv, theta, phi);
   %     b(i,j) = c;
    %    tener = tener + c;
    %end
%end
%b = b/2;
%c0 =c;
%c1 = c;
%tener = tener/2;                                %dividing by 2 to counter double counting
%minenergy = tener;

for k = 1: iterations
    i = irandom(m);
    j = irandom(n);

    [x(i,j), y(i,j), z(i,j)] = energycomp(i, j, jv, x, y, z);   %c
    %c = c/2;
    %tener = tener - b(i,j) + c;
    
    %b(i,j)  = c;

    %minenergy = tener;
    %p(k,1) = minenergy;
end
%rt = acos(x(1,1)*x(2,1)+y(1,1)*y(2,1)+z(1,1)*z(2,1))*180/pi;
%q = 1:1:iterations;
%figure;
%scatter(q,p,130,'.');

arrayplot(x,y,z);
%end
% if p(iterations,1) == 1
%     arrayplot(ox1,oy1,oz1);
%     arrayplot(ox2,oy2,oz2);
% else
%     arrayplot(x,y,z);
% end
                