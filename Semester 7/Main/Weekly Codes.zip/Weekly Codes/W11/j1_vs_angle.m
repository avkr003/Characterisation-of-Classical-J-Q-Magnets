j(1) = 1;
j(2) = 0;

j2u = 0.5;
j2s = 0.05;

j2t = 1 + j2u/j2s;

p = ones(j2t,1);
q = ones(j2t,1);

for k = 1: j2t
    q(k,1) = j(2);
    p(k,1) = w9(j);
    j(2) = j(2) + j2s;
end

figure;
scatter(q,p,130,'.');