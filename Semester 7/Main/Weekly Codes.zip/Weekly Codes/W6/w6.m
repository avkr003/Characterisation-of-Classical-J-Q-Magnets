syms theta phi;
syms o1 o2 o3;
syms tener minenergy c b;
syms x y z;

m = 4;
n = 4;                                    

jv(1) = 1;
jv(2) = 0.5;

tener = 0;
iterations = 200;

rand;                                           %first random number of matlab is not random so to call it for start

%c = zeros(m,n);                                  %variable to store new change
b = zeros(m,n);                                  % variable to store previous value before reorientation

p = ones(iterations,1);                         % plotting points

theta = pi* rand(m,n);                          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%33
phi = 2 * pi * rand(m,n);

x = sin(theta).*cos(phi);
y = sin(theta).*sin(phi);
z = cos(theta);  

for i = 1:m                                     %calculating total energy of system. Double counting is occuring
    for j = 1:n
        c = energy3dangle(i , j , jv, theta, phi);
        b(i,j) = c;
        tener = tener + c;
    end
end

tener = tener/2;                                %dividing by 2 to counter double counting
minenergy = tener;

for k = 1: iterations
    i = irandom(m);
    j = irandom(n);
    [x(i,j), y(i,j), z(i,j), c] = energycomp(i, j, jv, x, y, z);
    tener  = tener - b(i,j) + c;
    minenergy = tener;
    b(i,j)  = c;
    
    p(k,1) = minenergy;
    
end

q = 1:1:iterations;
figure;
scatter(q,p,16);

arrayplot(x,y,z);
                