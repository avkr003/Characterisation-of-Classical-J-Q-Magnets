function y = arrayplot2d(oren)

    compx = cos(flipud(oren));
    compy = sin(flipud(oren));
    
    figure;
    hold on;
    quiver(compx,compy);
    
end
