function y = irandom()
    syms z;
    z =  rand;
    if z <= 0.33
        y = 1;
    elseif z <= 0.66 && z > 0.33
        y = 2;
    elseif z <= 1 && z > 0.66
        y = 3;
    %elseif z >= 0.75
     %   y = 4;
    end
end
        