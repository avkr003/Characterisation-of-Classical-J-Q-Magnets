syms theta phi;
syms o1 o2;
syms tener minenergy c b;

m = 3;
n = 3;
p = 3;                                      

jv(3) = zeros;
jv(1) = 1;
jv(2) = 0;
jv(3) = 0;

tener = 0;
iterations = 10000;

rand;                                       %first random number of matlab is not random so to call it for start

c = ones(m,n,p);                            %variable to store new change
b = ones(m,n,p);                            % variable to store previous value before reorientation

z = ones(iterations,1);                     % plotting points

theta = pi * rand(m,n,p);
phi = 2 * pi * rand(m,n,p);



for k = 1:p
    for i = 1:m                                 %calculating total energy of system. Double counting is occuring
        for j = 1:n
            c(i,j,k) = energy3d(i , j ,k, jv, theta, phi);
            b(i,j,k) = c(i,j,k);
            tener = tener + c(i,j,k);
        end
    end
end

tener = tener/2;                                %dividing by 2 to counter double counting
minenergy = tener;

for iter = 1: iterations
    i = irandom();
    j = irandom();
    k = irandom();                          
    o1 = theta(i,j,k);
    o2 = phi(i,j,k);
    theta(i,j,k) = pi * rand;                 
    phi(i,j,k) = 2 * pi * rand;
    c(i,j,k) = energy3d(i , j , k, jv, theta, phi);        
    if minenergy >= (tener - b(i,j,k) + c(i,j,k))
        tener = tener - b(i,j,k) + c(i,j,k);
        minenergy = tener;
        b(i,j,k) = c(i,j,k);
    else
        theta(i,j,k) = o1;
        phi(i,j,k) = o2;
    end
    z(iter,1) = minenergy;
end
x = 1:1:iterations;
figure;
scatter(x,z,16);

arrayplot(theta,phi);
                