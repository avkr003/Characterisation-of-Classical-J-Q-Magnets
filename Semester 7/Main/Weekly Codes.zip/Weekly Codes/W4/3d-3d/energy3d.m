function y = energy3d(a,b,c, jv, theta, phi)
    syms m n p;
    [m,n,p] = size(theta);
    syms r1 r2 c1 c2 p1 p2;
    if a == 1 
        r1  = m;
    else
        r1 = a - 1;
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%   
    if b == 1 
        c1  = n;
    else
        c1 = b - 1;
    end
 %%%%%%%%%%%%%%%%%   
    if b == n 
        c2  = 1;
    else
        c2 = b + 1;
    end
 %%%%%%%%%%%%   
    if a == m 
        r2  = 1;
    else
        r2 = a + 1;
    end
    %%%%%%%%%%%%%
    if c == 1 
        p1  = p;
    else
        p1 = c - 1;
    end
 %%%%%%%%%%%%%%%%%   
    if c == p 
        p2  = 1;
    else
        p2 = c + 1;
    end
 %%%%%%%%%%%%  
    %q(26) = zeros;
    
    q(1)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(r1,b,c), phi(r1,b,c));
    q(2)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(r2,b,c), phi(r2,b,c));
    q(3)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(a,c1,c), phi(a,c1,c));
    q(4)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(a,c2,c), phi(a,c2,c));
    q(5)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(a,b,p1), phi(a,b,p1));
    q(6)  = calenergy(jv(1), theta(a,b,c), phi(a,b,c), theta(a,b,p2), phi(a,b,p2));
    
    q(7)  = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r1,b,p1), phi(r1,b,p1));
    q(8)  = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r2,b,p1), phi(r2,b,p1));
    q(9)  = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(a,c1,p1), phi(a,c1,p1));
    q(10) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(a,c2,p1), phi(a,c2,p1));
    q(11) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(a,c1,p2), phi(a,c1,p2));
    q(12) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(a,c2,p2), phi(a,c2,p2));
    q(13) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r1,c1,c), phi(r1,c1,c));
    q(14) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r2,c1,c), phi(r2,c1,c));
    q(15) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r1,c2,c), phi(r1,c2,c));
    q(16) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r2,c2,c), phi(r2,c2,c));
    q(17) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r1,b,p2), phi(r1,b,p2));
    q(18) = calenergy(jv(2), theta(a,b,c), phi(a,b,c), theta(r2,b,p2), phi(r2,b,p2));
    
    q(19) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r1,c1,p1), phi(r1,c1,p1));
    q(20) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r1,c1,p2), phi(r1,c1,p2));
    q(21) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r1,c2,p1), phi(r1,c2,p1));
    q(22) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r1,c2,p2), phi(r1,c2,p2));
    q(23) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r2,c1,p1), phi(r2,c1,p1));
    q(24) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r2,c1,p2), phi(r2,c1,p2));
    q(25) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r2,c2,p1), phi(r2,c2,p1));
    q(26) = calenergy(jv(3), theta(a,b,c), phi(a,b,c), theta(r2,c2,p2), phi(r2,c2,p2));
    
    y = sum(q);
end
