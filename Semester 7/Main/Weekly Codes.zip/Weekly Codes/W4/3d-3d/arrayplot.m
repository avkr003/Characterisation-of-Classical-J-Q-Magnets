function y = arrayplot(theta, phi)

    compx = sin(theta).*cos(phi);
    compy = sin(theta).*sin(phi);
    compz = cos(theta);
    
    [m,n,p] = size(phi);

    zp = zeros(3,3,3);
    for i = 1:p
        zp(:,:,i) = i;
    end

    figure;
    hold on;
    for k =  1:p
        quiver3(zp(:,:,k),compx(:,:,k),compy(:,:,k),compz(:,:,k));
    end
    
end
