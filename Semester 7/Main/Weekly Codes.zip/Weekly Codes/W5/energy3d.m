function y = energy3d(a, b, jv, theta, phi)
    syms m n;
    [m,n] = size(phi);
    syms r1 r2 c1 c2;
    
    if a == 1 
        r1  = m;
    else
        r1 = a - 1;
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%   
    if b == 1 
        c1  = n;
    else
        c1 = b - 1;
    end
 %%%%%%%%%%%%%%%%%   
    if b == n 
        c2  = 1;
    else
        c2 = b + 1;
    end
 %%%%%%%%%%%%   
    if a == m 
        r2  = 1;
    else
        r2 = a + 1;
    end
    %%%%%%%%%%%%%
    
%     q(1)  = calenergy(jv1, theta, phi(a,b), theta, phi(r1,b));
%     q(2)  = calenergy(jv1, theta, phi(a,b), theta, phi(r2,b));
%     q(3)  = calenergy(jv1, theta, phi(a,b), theta, phi(a,c1));
%     q(4)  = calenergy(jv1, theta, phi(a,b), theta, phi(a,c2));
%     
%     q(5) = calenergy(jv2, theta, phi(a,b), theta, phi(r1,c1));
%     q(6) = calenergy(jv2, theta, phi(a,b), theta, phi(r1,c2));
%     q(7) = calenergy(jv2, theta, phi(a,b), theta, phi(r2,c1));
%     q(8) = calenergy(jv2, theta, phi(a,b), theta, phi(r2,c2));
    
    q(1)  = calenergy(jv(1), theta(a,b), phi(a,b), theta(r1,b), phi(r1,b));
    q(2)  = calenergy(jv(1), theta(a,b), phi(a,b), theta(r2,b), phi(r2,b));
    q(3)  = calenergy(jv(1), theta(a,b), phi(a,b), theta(a,c1), phi(a,c1));
    q(4)  = calenergy(jv(1), theta(a,b), phi(a,b), theta(a,c2), phi(a,c2));
     
    q(5) = calenergy(jv(2), theta(a,b), phi(a,b), theta(r1,c1), phi(r1,c1));
    q(6) = calenergy(jv(2), theta(a,b), phi(a,b), theta(r1,c2), phi(r1,c2));
    q(7) = calenergy(jv(2), theta(a,b), phi(a,b), theta(r2,c1), phi(r2,c1));
    q(8) = calenergy(jv(2), theta(a,b), phi(a,b), theta(r2,c2), phi(r2,c2));
    
    y =  sum(q);
end
