function y = arrayplot(theta, phi)

    [m,n] = size(phi);
    
    compx = sin(flipud(theta)).*cos(flipud(phi));
    compy = sin(flipud(theta)).*sin(flipud(phi));
    compz = cos(flipud(theta));  

    zp = ones(m,n);

    figure;
    hold on;
    quiver3(zp,compx,compy,compz);   
end
