syms theta phi;
syms o1 o2;
syms tener minenergy c b;

m = 4;
n = 4;                                    

jv(1) = 1;
jv(2) = 0;

tener = 0;
iterations = 15000;

rand;                                           %first random number of matlab is not random so to call it for start

c = zeros(m,n);                                  %variable to store new change
b = zeros(m,n);                                  % variable to store previous value before reorientation

z = ones(iterations,1);                         % plotting points

theta = pi* rand(m,n);                       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%33
phi = 2 * pi * rand(m,n);

for i = 1:m                                     %calculating total energy of system. Double counting is occuring
    for j = 1:n
        c(i,j) = energy3d(i , j , jv, theta, phi);
        b(i,j) = c(i,j);
        tener = tener + c(i,j);
    end
end

tener = tener/2;                                %dividing by 2 to counter double counting
minenergy = tener;

for k = 1: iterations
    i = irandom(m);
    j = irandom(n);
    o2 = phi(i,j);
    phi(i,j) = 2 * pi * rand;
    c(i,j) = energy3d(i, j, jv, theta, phi);
    if minenergy > (tener - b(i,j) + c(i,j))
        tener = tener - b(i,j) + c(i,j);
        minenergy = tener;
        b(i,j) = c(i,j);
    else
        phi(i,j) = o2;
    end
     
     i = irandom(m);
     j = irandom(n);
    o1 = theta(i,j);    
     theta(i,j) = pi * rand;                                   
     c(i,j) = energy3d(i, j, jv, theta, phi);    
     if minenergy > (tener - b(i,j) + c(i,j))
         tener = tener - b(i,j) + c(i,j);
         minenergy = tener;
         b(i,j) = c(i,j);
     else
         theta(i,j) = o1;
     end
    z(k,1) = minenergy;
end

x = 1:1:iterations;
figure;
scatter(x,z,16);

arrayplot(theta,phi);
                